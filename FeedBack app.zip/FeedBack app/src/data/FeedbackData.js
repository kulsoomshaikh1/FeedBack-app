const FeedbackData = [
  {
    id: 1,
    rating: 10,
    text: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Id architecto illum reiciendis! A nihil incidunt laboriosam? Soluta aut vero, quas iusto commodi molestias necessitatibus veniam excepturi nobis non voluptas reiciendis! Esse, sapiente!',
  },
  {
    id: 2,
    rating: 8,
    text: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Id architecto illum reiciendis! A nihil incidunt laboriosam? Soluta aut vero, quas iusto commodi molestias necessitatibus veniam excepturi nobis non voluptas reiciendis! Esse, sapiente!',
  },
  {
    id: 3,
    rating: 7,
    text: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Id architecto illum reiciendis! A nihil incidunt laboriosam? Soluta aut vero, quas iusto commodi molestias necessitatibus veniam excepturi nobis non voluptas reiciendis! Esse, sapiente!',
  },
  {
    id: 4,
    rating: 9,
    text: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Id architecto illum reiciendis! A nihil incidunt laboriosam? Soluta aut vero, quas iusto commodi molestias necessitatibus veniam excepturi nobis non voluptas reiciendis! Esse, sapiente!',
  },
  {
    id: 5,
    rating: 2,
    text: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Id architecto illum reiciendis! A nihil incidunt laboriosam? Soluta aut vero, quas iusto commodi molestias necessitatibus veniam excepturi nobis non voluptas reiciendis! Esse, sapiente!',
  },
]

export default FeedbackData
